const User = require("./User");
const Trip = require("./Trip");
const Plan = require("./Plan")
const Fact = require("./Fact")

module.exports = { User, Trip, Plan, Fact };
